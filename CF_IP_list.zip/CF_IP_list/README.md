# Cloudflare IP列表自动更新脚本

使用 install_CFIP.sh 自动部署。